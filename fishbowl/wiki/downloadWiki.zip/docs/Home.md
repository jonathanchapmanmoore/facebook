**Dive into Fishbowl**

Welcome!  Fishbowl is a desktop application that lets you experience Facebook in new ways.  It was developed by some people at Microsoft to show off ways that a web platform can be leveraged as part of a desktop expierience.  We're providing the source to give people a chance to dig in and see how everything works.  This isn't intended to be an example of best practices.  It is an example of something that mostly works, and we hope that it's valuable for that.
We hope you like it.

**So long, and thanks for all the fish**
Fishbowl is no longer being actively maintained by Microsoft, but the application and source are still available.  If there is significant interest in turning the project into something community driven that may be an option in the future.

**Discuss on Facebook**
The support group for Fishbowl on Facebook is at [http://www.facebook.com/group.php?gid=148573025964](http://www.facebook.com/group.php?gid=148573025964).  Feel free to post developer-related conversations to the discussions tab in Codeplex.  The group page is a great place to discuss the actual product.

**NDepend**

Patrick Smacchia, the lead developer for the awesome tool NDepend, has graciously sponsored this project with a license to the tool.  NDepend provides a powerful view that allows you to understand and fluidly navigate how your project interacts with itself and dependencies.  Fishbowl is pretty big and complex, and this really provides a cohesive way to visualize how everything fits together.  Looking at the generated charts I'm surprised at the relative weight of some components :)   I strongly recommend this highly polished tool.  Check it out at [http://ndepend.com](http://ndepend.com).
